package com.demo.classes;


public class Calculator {
	
	private int num1,num2;

	public Calculator() {
		super();
	}

	public Calculator(int num1, int num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
	}

	public int getNum1() {
		return num1;
	}

	public void setNum1(int num1) {
		this.num1 = num1;
	}

	public int getNum2() {
		return num2;
	}

	public void setNum2(int num2) {
		this.num2 = num2;
	}
	public int addition() {
		if((num1 >0) && (num2>0))
		{
			return num1+num2;
		}else {
			if((num1 <0) && (num2<0)){
				return (num1+num2)*-1;
			}else {
				return num1+10;
			}
		}
	}
	public int subtraction() {
		if(num1<num2) {
			return num2-num1;
		}else {
			return num1-num2;
		}
	}
	
	public int mutiply() {
		return num1*num2;
	}
	
	public float divide() {
		if(num2!=0) {
			return (float)num1/num2;
		}else {
			throw new ArithmeticException("cannot divide by zero");
		}
	}
	
	

}
