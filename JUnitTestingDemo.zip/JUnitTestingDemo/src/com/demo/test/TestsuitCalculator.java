package com.demo.test;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class) 
@Suite.SuiteClasses({TestAddition.class,TestMultiplication.class,TestSubtrction.class})
public class TestsuitCalculator {
 @BeforeClass
	public static void testBeforeClass() {
	 System.out.println("in before class");
 }
 @AfterClass
 public static void testAfterClass() {
	 System.out.println("in After class");
 }
}
