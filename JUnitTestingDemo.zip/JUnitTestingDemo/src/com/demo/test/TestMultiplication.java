package com.demo.test;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.demo.classes.Calculator;

public class TestMultiplication {
	Calculator c;
	@Before
	public void dosetUp(){
		System.out.println("in before method");
		c=new Calculator(30,40);
	}
	
	@After
	public void docleanup() {
		System.out.println("in ndocleanup method");
	}
	
	
	@Test
	public void testMultiply(){
		System.out.println("in testMultiply");
		assertEquals(1200,c.mutiply());
		//c.setNum1(3);
	}
	
	@Test
	public void testdivision() {
		System.out.println("in testDivide");
		assertEquals(0.75,c.divide(),0.01);
	} 
	
	@Test
	public void testdivision1() {
		System.out.println("in testDivision1");
		Calculator c=new Calculator(10,30);
		System.out.println(c.divide());
		assertEquals(0.33333333,c.divide(),0.01);
	}
	
	@Test(expected = ArithmeticException.class)
	public void testdivision2() {
		System.out.println("in testdivision2");
		Calculator c=new Calculator(10,0);
		System.out.println(c.divide());
		
	}
	
	
	
}
