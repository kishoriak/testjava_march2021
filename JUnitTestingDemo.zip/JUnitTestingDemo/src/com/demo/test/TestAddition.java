package com.demo.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.demo.classes.Calculator;

public class TestAddition {
	
	@Test
	public void testpositive(){
		Calculator c=new Calculator(30,40);
		assertEquals(70,c.addition());
	}
	
	@Test
	public void testpositive1(){
		Calculator c=new Calculator(-30,-40);
		assertEquals(70,c.addition());
	}
	
	@Test
	public void testpositive2(){
		Calculator c=new Calculator(-30,40);
		assertEquals(-20,c.addition());
	}
	
	@Test
	public void testpositive3(){
		Calculator c=new Calculator(30,-40);
		assertEquals(40,c.addition());
	}
}
