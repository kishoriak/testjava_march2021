package com.demo.test;

import static org.junit.Assert.assertEquals;

import org.junit.Ignore;
import org.junit.Test;

import com.demo.classes.Calculator;

public class TestSubtrction {
	
	@Ignore("The method is being modified")
	@Test
	public void testSubtraction() {
		Calculator c=new Calculator(40,30);
		assertEquals(10,c.subtraction());
	}
	
	@Test
	public void testSubtraction1() {
		Calculator c=new Calculator(10,30);
		assertEquals(20,c.subtraction());
	}

}
