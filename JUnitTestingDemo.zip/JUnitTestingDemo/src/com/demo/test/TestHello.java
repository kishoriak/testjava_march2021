package com.demo.test;

import com.demo.classes.HelloWorld;

public class TestHello {

	public static void main(String[] args) {
		HelloWorld hw=new HelloWorld();
		System.out.println(hw.sayHello());

	}

}
