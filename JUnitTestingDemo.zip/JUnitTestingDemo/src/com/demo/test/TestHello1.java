package com.demo.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.demo.classes.HelloWorld;

public class TestHello1 {

	@Test
	public void test() {
		//fail("Not yet implemented");
		HelloWorld hw=new HelloWorld();
		assertEquals("Hello World!!!",hw.sayHello());
	}
	

}
